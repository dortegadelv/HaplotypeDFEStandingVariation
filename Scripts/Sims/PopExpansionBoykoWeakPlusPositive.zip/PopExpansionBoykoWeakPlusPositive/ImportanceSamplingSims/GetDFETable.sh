perl GetDFETable.pl ../../../../Results/PopExpansionBoykoPlusPositive/ImportanceSampling/TableToTest.txt ../../../../Results/PopExpansionBoykoPlusPositive/ImportanceSampling/DFETableToTest.txt
perl GetDFETableBoykoPlusPos.pl ../../../../Results/PopExpansionBoykoPlusPositive/ImportanceSampling/TableToTest.txt ../../../../Results/PopExpansionBoykoPlusPositive/ImportanceSampling/DFETableToTestBoykoPositive.txt

