File="../../../../Results/PopExpansionBoykoPlusPositive/ForwardSims/BoykoPart/ReducedTrajectories.txt"
ExitFile="../../../../Results/PopExpansionBoykoPlusPositive/ForwardSims/BoykoPart/ReducedTrajectories50000.txt"
perl ../../ConstantPopSize/ForwardSims/PrintThisTrajectoryNumber.pl $File 50000 $ExitFile

File="../../../../Results/PopExpansionBoykoPlusPositive/ForwardSims/PositivePart/ReducedTrajectories.txt"
ExitFile="../../../../Results/PopExpansionBoykoPlusPositive/ForwardSims/PositivePart/ReducedTrajectories50000.txt"
perl ../../ConstantPopSize/ForwardSims/PrintThisTrajectoryNumber.pl $File 50000 $ExitFile
