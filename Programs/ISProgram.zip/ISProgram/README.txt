Compile using this on the pps cluster:

g++44 -o SlatkinISConstantSizeF SlatkinISConstantSizeSISR.cpp prob.cpp -lm
